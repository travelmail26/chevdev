import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

const PERPLEXITY_API_URL = "https://api.perplexity.ai/chat/completions";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.threads.list.path, async (req, res) => {
    const threads = await storage.getThreads();
    res.json(threads);
  });

  app.post(api.threads.create.path, async (req, res) => {
    const input = api.threads.create.input.parse(req.body);
    const thread = await storage.createThread(input.title);
    res.status(201).json(thread);
  });

  app.get(api.threads.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const thread = await storage.getThread(id);
    if (!thread) {
      return res.status(404).json({ message: "Thread not found" });
    }
    const messages = await storage.getThreadMessages(id);
    res.json({ ...thread, messages });
  });

  app.post(api.chat.sendMessage.path, async (req, res) => {
    try {
      const { message, threadId: inputThreadId, model: requestedModel } = api.chat.sendMessage.input.parse(req.body);

      const apiKey = process.env.PERPLEXITY_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ message: "Perplexity API key not configured" });
      }

      let threadId = inputThreadId;
      if (!threadId) {
        const thread = await storage.createThread(message.slice(0, 50) + (message.length > 50 ? "..." : ""));
        threadId = thread.id;
      }

      await storage.createMessage({
        threadId,
        role: "user",
        content: message,
        sources: [],
      });

      const existingMessages = await storage.getThreadMessages(threadId);
      const conversationHistory = existingMessages
        .filter(m => m.role === "user" || m.role === "assistant")
        .slice(-10)
        .map(m => ({
          role: m.role as "user" | "assistant",
          content: m.content,
        }));

      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.setHeader("X-Accel-Buffering", "no");
      res.flushHeaders();

      const sendEvent = (event: string, data: any) => {
        res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      };

      sendEvent("meta", { threadId });
      sendEvent("status", { phase: "searching", text: "Searching the web..." });

      try {
        const perplexityRes = await fetch(PERPLEXITY_API_URL, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: requestedModel || "sonar",
            messages: conversationHistory,
            stream: true,
          }),
        });

        if (!perplexityRes.ok) {
          const errText = await perplexityRes.text();
          console.error("Perplexity API error:", perplexityRes.status, errText);
          sendEvent("error", { message: `API error: ${perplexityRes.status}` });
          res.end();
          return;
        }

        if (!perplexityRes.body) {
          sendEvent("error", { message: "No response body from API" });
          res.end();
          return;
        }

        const reader = perplexityRes.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        let fullContent = "";
        let inThinking = false;
        let thinkingContent = "";
        let answerStarted = false;
        let sourcesSent = false;
        let finalSources: Array<{ title: string; url: string; snippet: string }> = [];

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const dataStr = line.slice(6).trim();
            if (dataStr === "[DONE]") continue;

            try {
              const chunk = JSON.parse(dataStr);

              if (!sourcesSent && chunk.search_results && chunk.search_results.length > 0) {
                finalSources = chunk.search_results.map((sr: any, i: number) => ({
                  title: sr.title || `Source ${i + 1}`,
                  url: sr.url || "",
                  snippet: sr.snippet || "",
                }));
                sendEvent("sources", { sources: finalSources });
                sourcesSent = true;
              } else if (!sourcesSent && chunk.citations && chunk.citations.length > 0) {
                finalSources = chunk.citations.map((url: string, i: number) => ({
                  title: `Source ${i + 1}`,
                  url,
                  snippet: "",
                }));
                sendEvent("sources", { sources: finalSources });
                sourcesSent = true;
              }

              const delta = chunk.choices?.[0]?.delta;
              if (!delta?.content) continue;

              let text = delta.content;

              if (text.includes("<think>")) {
                inThinking = true;
                sendEvent("status", { phase: "thinking", text: "Reasoning..." });
                text = text.split("<think>").pop() || "";
                if (!text) continue;
              }

              if (inThinking) {
                if (text.includes("</think>")) {
                  const parts = text.split("</think>");
                  const beforeClose = parts[0] || "";
                  const afterClose = parts.slice(1).join("") || "";

                  if (beforeClose) {
                    thinkingContent += beforeClose;
                    sendEvent("thinking", { content: beforeClose });
                  }

                  inThinking = false;

                  if (afterClose && afterClose.trim()) {
                    if (!answerStarted) {
                      answerStarted = true;
                      sendEvent("status", { phase: "answering", text: "Writing answer..." });
                    }
                    fullContent += afterClose;
                    sendEvent("content", { text: afterClose });
                  }
                  continue;
                }
                thinkingContent += text;
                sendEvent("thinking", { content: text });
                continue;
              }

              if (!answerStarted) {
                answerStarted = true;
                sendEvent("status", { phase: "answering", text: "Writing answer..." });
              }
              fullContent += text;
              sendEvent("content", { text });
            } catch (e) {
              // skip malformed chunks
            }
          }
        }

        await storage.createMessage({
          threadId,
          role: "assistant",
          content: fullContent,
          sources: finalSources,
        });

        sendEvent("done", { threadId });
        res.end();

      } catch (apiError: any) {
        console.error("Perplexity streaming error:", apiError);
        sendEvent("error", { message: apiError.message || "Streaming failed" });
        res.end();
      }

    } catch (error: any) {
      console.error("Chat route error:", error);
      if (!res.headersSent) {
        res.status(500).json({ message: "Internal server error" });
      } else {
        res.end();
      }
    }
  });

  return httpServer;
}
