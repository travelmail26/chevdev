
import { db } from "./db";
import { threads, messages, type Thread, type Message, type InsertMessage } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createThread(title?: string): Promise<Thread>;
  getThreads(): Promise<Thread[]>;
  getThread(id: number): Promise<Thread | undefined>;
  getThreadMessages(threadId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class DatabaseStorage implements IStorage {
  async createThread(title: string = "New Thread"): Promise<Thread> {
    const [thread] = await db.insert(threads).values({ title }).returning();
    return thread;
  }

  async getThreads(): Promise<Thread[]> {
    return await db.select().from(threads).orderBy(desc(threads.createdAt));
  }

  async getThread(id: number): Promise<Thread | undefined> {
    const [thread] = await db.select().from(threads).where(eq(threads.id, id));
    return thread;
  }

  async getThreadMessages(threadId: number): Promise<Message[]> {
    return await db.select()
      .from(messages)
      .where(eq(messages.threadId, threadId))
      .orderBy(messages.createdAt);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [msg] = await db.insert(messages).values(message).returning();
    return msg;
  }
}

export const storage = new DatabaseStorage();
