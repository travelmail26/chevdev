
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/getLatestStatus.mjs
import { MongoClient } from "mongodb";
var MONGODB_URI = process.env.MONGODB_URI || "";
var DB_NAME = process.env.DATABASE_NAME || "chef_chatbot";
var COLLECTION_NAME = process.env.COLLECTION_NAME || "user_recipe_status";
var STATUS_API_KEY = process.env.STATUS_API_KEY || "";
var cachedClient;
async function getClient() {
  if (!cachedClient) {
    cachedClient = new MongoClient(MONGODB_URI, { serverSelectionTimeoutMS: 5e3 });
    await cachedClient.connect();
  }
  return cachedClient;
}
function extractApiKey(req) {
  const headerKey = req.headers.get("x-api-key");
  if (headerKey) return headerKey.trim();
  const authHeader = req.headers.get("authorization") || "";
  if (authHeader.toLowerCase().startsWith("bearer ")) {
    return authHeader.slice(7).trim();
  }
  return "";
}
var getLatestStatus_default = async (req) => {
  try {
    if (req.method !== "GET") {
      return new Response(JSON.stringify({ error: "method not allowed" }), {
        status: 405,
        headers: { "Content-Type": "application/json" }
      });
    }
    if (!STATUS_API_KEY) {
      return new Response(JSON.stringify({ error: "STATUS_API_KEY not set" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    if (!MONGODB_URI) {
      return new Response(JSON.stringify({ error: "MONGODB_URI not set" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    const providedKey = extractApiKey(req);
    if (!providedKey || providedKey !== STATUS_API_KEY) {
      return new Response(JSON.stringify({ error: "unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      });
    }
    const url = new URL(req.url);
    const userId = (url.searchParams.get("user_id") || "").trim();
    if (!userId) {
      return new Response(JSON.stringify({ error: "user_id required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const client = await getClient();
    const collection = client.db(DB_NAME).collection(COLLECTION_NAME);
    const doc = await collection.findOne(
      { user_id: userId },
      { sort: { updated_at: -1 } }
    );
    if (!doc) {
      return new Response(
        JSON.stringify({ user_id: userId, latest_step: null, updated_at: null }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    const latestStep = doc.latest_step || doc.step || doc.status || null;
    let updatedAt = doc.updated_at || doc.created_at || null;
    if (updatedAt instanceof Date) updatedAt = updatedAt.toISOString();
    return new Response(
      JSON.stringify({ user_id: userId, latest_step: latestStep, updated_at: updatedAt }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: "internal error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
export {
  getLatestStatus_default as default
};
