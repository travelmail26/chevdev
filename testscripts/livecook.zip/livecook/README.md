# LiveCook Recorder

Chrome-focused browser app with two capture paths:

- Low-res always-on recording with live video preview and mic level meter.
- Low-res auto-saves rolling 30-second clips while recording.
- Voice command `"record"` triggers high-res recording for 10 seconds (default).
- Voice command `"stop"` stops low-res and high-res recording.
- Fixed wake word: `record`.
- Live transcription panel showing latest and full-session recognized speech with timestamps.
- Live diagnostics panel with timestamped STT/microphone/restart events.
- Onboard wake-word transcription module in `onboardTranscriber.js` (uses on-device mode in Chrome when available).
- Automatic fallback to browser transcription when on-device language support is unavailable.

## Run

```bash
cd /workspaces/chefresearch/livecook
npm install
npm start
```

Open: `http://127.0.0.1:4173`

## Use

1. Click **Start low-res recording**.
2. Speak `record` to trigger 10-second high-res capture.
3. Speak `stop` to stop all recording.
4. Watch recognized speech in **Live transcription** (wall-clock and session elapsed time).
5. Download clips from the **Saved clips** section.

## Validate

Automated simulation tests (fake camera/microphone + wake-word trigger):

```bash
cd /workspaces/chefresearch/livecook
npm test
```
